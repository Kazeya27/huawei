# -*- coding: utf-8 -*-
"""
@author:
"""


import os
import copy
import joblib
import argparse
import torch
from engine.util import check_dir
from engine.util import parse_config
from engine.data_io import get_seq_dim
from engine.data_io import get_largest_loader as get_loader
from engine.model import get_model
from engine.train_test import nn_test
from engine.train_test import get_largest_metric as get_metric


def main_wrapper():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir')
    parser.add_argument('--train_data_name')
    parser.add_argument('--test_data_name')
    parser.add_argument('--method_name')
    parser.add_argument('--n_worker', type=int)

    args = parser.parse_args()
    data_dir = args.data_dir
    train_data_name = args.train_data_name
    test_data_name = args.test_data_name
    method_name = args.method_name
    n_worker = args.n_worker
    main(data_dir, train_data_name, test_data_name,
         method_name, n_worker)


def main(data_dir, train_data_name, test_data_name, method_name, n_worker):
    model_dir = os.path.join(
        '.', 'model', train_data_name)
    result_dir = os.path.join(
        '.', 'result', f'{train_data_name}_{test_data_name}')
    check_dir(model_dir)
    check_dir(result_dir)

    data_config = os.path.join(
        '.', 'config', f'{test_data_name}.config')
    data_config = parse_config(data_config, verbose=True)
    data_config['data']['data_path'] = os.path.join(
        data_dir, data_config['data']['data_path'])

    method_config = os.path.join(
        '.', 'config', f'{method_name}.config')
    method_config = parse_config(method_config, verbose=True)

    config = copy.deepcopy(method_config)
    config['data'] = data_config['data']
    config['data']['seq_len'] = config['model']['seq_len']
    config['model']['pred_len'] = config['data']['pred_len']
    config['model']['seq_dim'] = get_seq_dim(config)
    feature_variant = int(config['data']['feature_variant'])
    seq_len = int(config['data']['seq_len'])
    if feature_variant == 0:
        feat_dim = 0
    elif feature_variant == 1:
        feat_dim = seq_len * 2
    elif feature_variant == 2:
        feat_dim = 10
    config['model']['feat_dim'] = feat_dim

    if torch.cuda.is_available():
        device = 'cuda'
    else:
        device = 'cpu'
    print(device)

    fmt_str = '{0:04d}'
    model_path = os.path.join(
        model_dir, f'{method_name}_{fmt_str}.pt')
    result_path = os.path.join(
        result_dir, f'{method_name}_{fmt_str}.joblib')

    model_path_final = model_path.format(9999)
    result_path_final = result_path.format(9999)
    if not os.path.isfile(model_path_final):
        return
    if os.path.isfile(result_path_final):
        return

    print(f'loading {model_path_final}')
    model = get_model(config)
    model_pkl = torch.load(model_path_final, map_location='cpu')
    model.load_state_dict(
        model_pkl['model_state_dict'])
    model.to(device)

    loader_test, dataset_test = get_loader(
        'test', config, n_worker, is_pad=False)
    is_inverse = True
    metric_test = nn_test(
                    loader_test, dataset_test, model,
                    get_metric, device, is_inverse, False)
    result_pkl = {}
    result_pkl['metric_test'] = metric_test
    result_pkl['n_param'] = model.get_n_param()
    joblib.dump(result_pkl, result_path_final)

if __name__ == '__main__':
    main_wrapper()

