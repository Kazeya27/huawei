# -*- coding: utf-8 -*-
"""
@author:
"""


import argparse
import random
from script_nn_exp import main as main_nn_exp
from script_transfer import main as main_transfer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir')
    parser.add_argument('--n_worker', type=int, default=4)

    args = parser.parse_args()
    data_dir = args.data_dir
    n_worker = args.n_worker

    exp_setup = []
    data_names = [
        'ca_his_2019_agg',
        'gba_his_2019_agg',
        'gla_his_2019_agg',
        'sd_his_2019_agg',
    ]

    method_names = [
        'lin_0000',
        'tsm_0000',
        'rpm_0000',
        'itx_0000',
        'spa_0000',
        'spa_0001',
        'spa_0002',
        'spa_0003',
        'ult_0000',
    ]
    setup_id = 0
    for data_name in data_names:
        for method_name in method_names:
            if (method_name == 'itx_0000' and
                    data_name != 'sd_his_2019_agg'):
                continue
            exp_setup.append(
                [data_name + f'_{setup_id:04d}', method_name,])

    random.shuffle(exp_setup)
    for data_name, method_name in exp_setup:
        print(data_name, method_name)
        main_nn_exp(data_dir, data_name, method_name, n_worker)

    exp_setup = []
    data_names = [
        'gba_his_2019_agg',
        'gla_his_2019_agg',
        'sd_his_2019_agg',
    ]

    method_names = [
        'lin_0000',
        'itx_0000',
        'spa_0000',
        'spa_0001',
        'spa_0002',
        'spa_0003',
        'ult_0000',
    ]
    setup_id = 0
    for train_data_name in data_names:
        for test_data_name in data_names:
            if train_data_name == test_data_name:
                continue
            for method_name in method_names:
                exp_setup.append(
                    [train_data_name + f'_{setup_id:04d}',
                     test_data_name + f'_{setup_id:04d}',
                     method_name,])

    random.shuffle(exp_setup)
    for train_data_name, test_data_name, method_name in exp_setup:
        print(train_data_name, test_data_name, method_name)
        main_transfer(data_dir, train_data_name, test_data_name,
                      method_name, n_worker)


if __name__ == '__main__':
    main()

