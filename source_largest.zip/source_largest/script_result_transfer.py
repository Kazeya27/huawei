# -*- coding: utf-8 -*-
"""
@author:
"""

import os
import joblib
import numpy as np


def print_result(data_config, method, method_name, is_first):
    result_dir = os.path.join(
        '.', 'result', data_config)

    result_path = os.path.join(
        result_dir, f'{method}_9999.joblib')
    if not os.path.exists(result_path):
        return

    result_pkl = joblib.load(result_path)
    metric_test = result_pkl['metric_test']

    if is_first:
        output_str = f'{method_name},{result_pkl["n_param"]},'
        print(output_str, end='')
    output_str = f"{np.mean(metric_test['mae']):.2f},"
    print(output_str, end='')


def main():
    data_names = [
        'sd_his_2019_agg',
        'gba_his_2019_agg',
        'gla_his_2019_agg',
    ]

    methods = [
        'lin_0000',
        'itx_0000',
        'spa_0000',
        'spa_0001',
        'spa_0002',
        'spa_0003',
        'ult_0000',
    ]

    method_names = [
        'Linear',
        'iTransformer',
        'SparseTSF',
        'SparseTSF+MLP',
        'SparseTSF+MLPx4',
        'SparseTSF+SA',
        'UltraSTF',
    ]

    for train_data_name in data_names:
        print(train_data_name)

        output_str = ',,'
        for test_data_name in data_names:
            output_str += f'{test_data_name},,,'
        print(output_str)
        print('method,n_param,MAE(avg),')
        for method, method_name in zip(methods, method_names):
            is_first = True
            for test_data_name in data_names:
                if train_data_name == test_data_name:
                    data_config = f'{train_data_name}_0000'
                else:
                    data_config = (f'{train_data_name}_0000_'
                                   f'{test_data_name}_0000')

                print_result(data_config, method, method_name, is_first)
                is_first = False
            print()
        print()


if __name__ == '__main__':
    main()

