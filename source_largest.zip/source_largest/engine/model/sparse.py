# -*- coding: utf-8 -*-
"""
@author:
"""


import numpy as np
import torch
import torch.nn as nn
from collections import OrderedDict


class _Encoder(nn.Module):
    def __init__(self, seq_len, pred_len, seq_dim, period_len, n_hidden,
                 is_shape, n_shape, is_conv):
        super(_Encoder, self).__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.seq_dim = seq_dim

        self.period_len = period_len
        self.n_hidden = n_hidden
        self.is_shape = is_shape
        self.n_shape = n_shape
        self.is_conv = is_conv

        self.seg_num_x = int(np.floor(self.seq_len / self.period_len))
        self.seg_num_y = int(np.ceil(self.pred_len / self.period_len))

        if self.is_conv:
            padding = int(self.period_len // 2)
            kernel_size = int(1 + 2 * padding)
            self.conv1d = nn.Conv1d(
                in_channels=1, out_channels=1, kernel_size=kernel_size,
                stride=1, padding=padding, padding_mode="zeros", bias=False)

        if self.is_shape == 1:
            key = torch.randn(self.n_shape, self.period_len)
            self.key = torch.nn.Parameter(key)

            value = torch.randn(self.n_shape, self.period_len)
            self.value = torch.nn.Parameter(value)

            self.linear_d = nn.Linear(
                self.period_len, self.period_len, bias=False)

        elif self.is_shape == 2:
            feat_len = self.period_len * self.seg_num_x

            key = torch.randn(1, self.n_shape, feat_len)
            self.key = torch.nn.Parameter(key)
            self.register_parameter(name='key', param=self.key)

            value = torch.randn(1, self.n_shape, feat_len)
            self.value = torch.nn.Parameter(value)
            self.register_parameter(name='value', param=self.value)

            n_heads = 8
            dropout = 0.0
            self.attention = nn.MultiheadAttention(
                feat_len, n_heads, dropout=dropout, batch_first=True)

        if self.n_hidden == 0:
            self.linear_t = nn.Linear(
                self.seg_num_x, self.seg_num_y, bias=False)
        elif self.n_hidden > 0:
            self.linear_t_0 = nn.Linear(
                self.seg_num_x, self.n_hidden, bias=False)
            self.linear_t_1 = nn.Linear(
                self.n_hidden, self.seg_num_y, bias=False)

    def forward(self, x):
        # x = [batch_size, seq_dim, seq_len, ]
        # y = [batch_size, seq_dim, pred_len, ]
        batch_size = x.shape[0]
        x = x[:, :, :self.seq_len]

        seq_len_normed = self.seg_num_x * self.period_len
        pred_len_normed = self.seg_num_y * self.period_len
        x = x[:, :, :seq_len_normed]

        if self.is_conv:
            x = self.conv1d(
                x.reshape(-1, 1, seq_len_normed)).reshape(
                    -1, self.seq_dim, seq_len_normed) + x

        if self.is_shape == 1:
            x = x.reshape(-1, self.seq_dim, self.seg_num_x, self.period_len)
            query = self.linear_d(x)

            key = self.key
            value = self.value

            # attn = torch.einsum('bcnw,rw->bcnr', query, key)
            # attn = nn.ReLU()(attn)
            # x = x + torch.einsum('bcnr,rw->bcnw', attn, value)

            key = key.permute(1, 0)  # wr
            attn = torch.matmul(query, key)  # bcnr
            attn = nn.ReLU()(attn)
            h = torch.matmul(attn, value)  # bcnw
            x = x + h

        elif self.is_shape == 2:
            feat_len = self.period_len * self.seg_num_x
            x = x.reshape(-1, self.seq_dim, feat_len)

            key = self.key.expand(x.shape[0], -1, -1)
            value = self.value.expand(x.shape[0], -1, -1)
            h, _ = self.attention.forward(
                x, key, value, need_weights=False)
            x = x + h
            x = x.reshape(-1, self.seq_dim, self.seg_num_x, self.period_len)

        # reshape: b,c,s -> bc,n,w -> bc,w,n
        x = x.reshape(-1, self.seg_num_x, self.period_len).permute(0, 2, 1)

        # linear: bc,w,n -> bc,w,m
        if self.n_hidden == 0:
            y = self.linear_t(x)
        elif self.n_hidden > 0:
            h = self.linear_t_0(x)
            h = nn.ReLU()(h)
            y = self.linear_t_1(h)

        # reshape: bc,w,m -> bc,m,w -> b,c,s
        y = y.permute(0, 2, 1).reshape(
            batch_size, self.seq_dim, pred_len_normed)
        y = y[:, :, :self.pred_len]
        return y


class SparseTSF(nn.Module):
    def __init__(self, seq_len, pred_len, seq_dim, period_len, n_hidden,
                 is_shape, n_shape, is_normal, n_layer):
        super(SparseTSF, self).__init__()
        self.model_name = 'SparseTSF'

        self.seq_len = seq_len
        self.is_normal = is_normal

        layers = OrderedDict()
        for i in range(n_layer):
            if i == 0:
                is_conv = True
            else:
                is_conv = False

            if i == n_layer - 1:
                pred_len_ = pred_len
            else:
                pred_len_ = seq_len

            layers[f'encoder_{i}'] = _Encoder(
                seq_len, pred_len_, seq_dim, period_len, n_hidden,
                is_shape, n_shape, is_conv)

        encoder = nn.Sequential(layers)
        self.add_module('encoder', encoder)
        self.encoder_layers = layers
        self.encoder = encoder

    def forward(self, x):
        # x = [batch_size, seq_dim, seq_len, ]
        # y = [batch_size, seq_dim, pred_len, ]
        x = x[:, :, :self.seq_len]
        if self.is_normal:
            x_ = x.detach()
            x_mu = torch.mean(x_, 2, keepdim=True)
            x_sigma = torch.std(x_, 2, keepdim=True)
            x_sigma[x_sigma < 1e-6] = 1.0
            x = (x - x_mu) / x_sigma

        y = self.encoder(x)

        if self.is_normal:
            y = (y * x_sigma) + x_mu
        return y

    def get_n_param(self):
        n_param = 0
        for param in self.parameters():
            if param.requires_grad:
                n_param += torch.numel(param)
        return n_param

