# -*- coding: utf-8 -*-
"""
@author:
"""


import torch
import torch.nn as nn
from collections import OrderedDict


class Linear(nn.Module):
    """
    Linear model
    """

    def __init__(self, seq_len, pred_len, seq_dim, feat_dim,
                 n_layer, is_normal):
        super(Linear, self).__init__()
        self.model_name = 'Linear'
        seq_feat_len = seq_len + feat_dim

        if n_layer == 1:
            encoder = nn.Identity()
        else:
            layers = OrderedDict()
            for i in range(n_layer - 1):
                layers[f'linear_{i}'] = nn.Linear(
                    seq_feat_len, seq_feat_len)
                layers[f'relu_{i}'] = nn.ReLU()
            encoder = nn.Sequential(layers)
        decoder = nn.Linear(
            seq_feat_len, pred_len)
        self.add_module('encoder', encoder)
        self.add_module('decoder', decoder)

        self.encoder = encoder
        self.decoder = decoder

        self.seq_len = seq_len
        self.pred_len = pred_len
        self.seq_dim = seq_dim
        self.is_normal = is_normal

    def forward(self, x):
        # x = [batch_size, seq_dim, seq_len, ]
        # y = [batch_size, seq_dim, pred_len, ]

        is_normal = self.is_normal
        seq_len = self.seq_len
        if is_normal:
            x_ = x.detach()
            x_mu = torch.mean(x_[:, :, :seq_len], 2, keepdim=True)
            x_sigma = torch.std(x_[:, :, :seq_len], 2, keepdim=True)
            x_sigma[x_sigma < 1e-6] = 1.0
            x[:, :, :seq_len] = (x[:, :, :seq_len] - x_mu) / x_sigma

        h = self.encoder(x)
        y = self.decoder(h)

        if is_normal:
            y = (y * x_sigma) + x_mu
        return y

    def get_n_param(self):
        n_param = 0
        for param in self.parameters():
            n_param += torch.numel(param)
        return n_param

