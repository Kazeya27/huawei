# -*- coding: utf-8 -*-
"""
@author:
"""


import time
from .linear import Linear
from .tsmixer import TSMixer
from .rpmixer import RPMixer
from .itrans import iTransformer
from .sparse import SparseTSF
from .ultra import UltraSTF


def get_rpmixer(config):
    seq_len = int(config['seq_len'])
    pred_len = int(config['pred_len'])
    seq_dim = int(config['seq_dim'])
    feat_dim = int(config['feat_dim'])
    proj_dim = int(config['proj_dim'])
    dim_factor = float(config['dim_factor'])
    n_layer = int(config['n_layer'])
    norm_layer = config['norm_layer']
    activation = config['activation']

    is_preact = config['is_preact']
    is_preact = is_preact.lower() == 'true'
    is_random = config['is_random']
    is_random = is_random.lower() == 'true'
    is_normal = config['is_normal']
    is_normal = is_normal.lower() == 'true'
    is_freq = config['is_freq']
    is_freq = is_freq.lower() == 'true'

    model = RPMixer(seq_len, pred_len, seq_dim, feat_dim, proj_dim,
                    dim_factor, n_layer, norm_layer, activation, is_preact,
                    is_random, is_normal, is_freq)
    return model


def get_itrans(config):
    seq_len = int(config['seq_len'])
    pred_len = int(config['pred_len'])
    feat_dim = int(config['feat_dim'])
    d_model = int(config['d_model'])
    n_heads = int(config['n_heads'])
    d_ff = int(config['d_ff'])
    n_layer = int(config['n_layer'])
    dropout = float(config['dropout'])

    is_normal = config['is_normal']
    is_normal = is_normal.lower() == 'true'

    model = iTransformer(seq_len, pred_len, feat_dim,
                         d_model, n_heads, d_ff, n_layer,
                         is_normal, dropout)
    return model


def get_linear(config):
    seq_len = int(config['seq_len'])
    pred_len = int(config['pred_len'])
    seq_dim = int(config['seq_dim'])
    feat_dim = int(config['feat_dim'])
    n_layer = int(config['n_layer'])

    is_normal = config['is_normal']
    is_normal = is_normal.lower() == 'true'

    model = Linear(seq_len, pred_len, seq_dim, feat_dim, n_layer, is_normal)
    return model


def get_tsmixer(config):
    seq_len = int(config['seq_len'])
    pred_len = int(config['pred_len'])
    seq_dim = int(config['seq_dim'])
    feat_dim = int(config['feat_dim'])
    hidden_dim = int(config['hidden_dim'])
    n_block = int(config['n_block'])
    activation = config['activation']
    dropout = float(config['dropout'])

    is_normal = config['is_normal']
    is_normal = is_normal.lower() == 'true'

    model = TSMixer(seq_len, pred_len, seq_dim, feat_dim,
                    hidden_dim, n_block, activation, dropout,
                    is_normal)
    return model


def get_sparse(config):
    seq_len = int(config['seq_len'])
    pred_len = int(config['pred_len'])
    seq_dim = int(config['seq_dim'])
    period_len = int(config['period_len'])
    n_hidden = int(config['n_hidden'])
    is_shape = int(config['is_shape'])
    n_shape = int(config['n_shape'])
    n_layer = int(config['n_layer'])

    is_normal = config['is_normal']
    is_normal = is_normal.lower() == 'true'

    model = SparseTSF(seq_len, pred_len, seq_dim, period_len, n_hidden,
                      is_shape, n_shape, is_normal, n_layer)
    return model


def get_ultra(config):
    seq_len = int(config['seq_len'])
    pred_len = int(config['pred_len'])
    seq_dim = int(config['seq_dim'])
    period_len = int(config['period_len'])
    n_shape = int(config['n_shape'])
    n_layer = int(config['n_layer'])

    is_normal = config['is_normal']
    is_normal = is_normal.lower() == 'true'

    model = UltraSTF(seq_len, pred_len, seq_dim, period_len,
                     n_shape, is_normal, n_layer)
    return model


def get_model(config, verbose=True):
    config = config['model']
    model_name = config['model_name']
    if verbose:
        print(f'get {model_name}... ', end='')
    tic = time.time()
    if model_name == 'Linear':
        model = get_linear(config)
    elif model_name == 'TSMixer':
        model = get_tsmixer(config)
    elif model_name == 'RPMixer':
        model = get_rpmixer(config)
    elif model_name == 'iTransformer':
        model = get_itrans(config)
    elif model_name == 'SparseTSF':
        model = get_sparse(config)
    elif model_name == 'UltraSTF':
        model = get_ultra(config)

    toc = time.time() - tic
    if verbose:
        print(f'done! {toc:0.2f}')
    return model

