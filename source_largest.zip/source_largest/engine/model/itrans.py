# -*- coding: utf-8 -*-
"""
@author:
"""


import torch
import torch.nn as nn
from collections import OrderedDict


class _EncoderLayer(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, dropout):
        super(_EncoderLayer, self).__init__()
        self.attention = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True)
        self.lin1 = nn.Linear(d_model, d_ff)
        self.lin2 = nn.Linear(d_ff, d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.GELU()


    def forward(self, x):
        h, _ = self.attention(
            x, x, x, need_weights=False)
        h = self.dropout(h)
        x = self.norm1(x + h)

        h = self.lin1(x)
        h = self.activation(h)
        h = self.dropout(h)
        h = self.lin2(h)
        h = self.dropout(h)
        y = self.norm2(x + h)
        return y


class iTransformer(nn.Module):
    """
    iTransformer network

    modified from https://github.com/thuml/iTransformer/tree/main
    """

    def __init__(self, seq_len, pred_len, feat_dim,
                 d_model, n_heads, d_ff, n_layer,
                 is_normal, dropout):
        super(iTransformer, self).__init__()
        self.model_name = 'iTransformer'
        seq_feat_len = seq_len + feat_dim

        layers = OrderedDict()
        layers['linear_0'] = nn.Linear(seq_feat_len, d_model)
        for i in range(n_layer):
            layers[f'encoder_{i}'] = _EncoderLayer(
                d_model, n_heads, d_ff, dropout)

        encoder = nn.Sequential(layers)
        self.add_module(f'encoder', encoder)
        self.encoder_layers = layers

        decoder = nn.Linear(d_model, pred_len)
        self.add_module(f'decoder', decoder)
        self.decoder = decoder

        self.seq_len = seq_len
        self.pred_len = pred_len
        self.is_normal = is_normal

    def forward(self, x):
        # x = [batch_size, seq_dim, seq_len, ]
        # y = [batch_size, seq_dim, pred_len, ]
        is_normal = self.is_normal
        seq_len = self.seq_len
        if is_normal:
            x_ = x.detach()
            x_mu = torch.mean(x_[:, :, :seq_len], 2, keepdim=True)
            x_sigma = torch.std(x_[:, :, :seq_len], 2, keepdim=True)
            x_sigma[x_sigma < 1e-6] = 1.0
            x[:, :, :seq_len] = (x[:, :, :seq_len] - x_mu) / x_sigma

        h = self.encoder(x)
        y = self.decoder(h)

        if is_normal:
            y = (y * x_sigma) + x_mu
        return y

    def get_n_param(self):
        n_param = 0
        for param in self.parameters():
            if param.requires_grad:
                n_param += torch.numel(param)
        return n_param

