# -*- coding: utf-8 -*-
"""
@author: 
"""


import numpy as np
import torch
import torch.nn as nn
from collections import OrderedDict


class Block(nn.Module):
    def __init__(self, seq_len, pred_len, seq_dim, period_len,
                 n_shape, n_head):
        super(Block, self).__init__()
        n_seg_x = int(np.floor(seq_len / period_len))
        n_seg_y = int(np.ceil(pred_len / period_len))

        intra_key = torch.randn(n_shape, period_len)
        self.intra_key = nn.Parameter(intra_key)

        intra_value = torch.randn(n_shape, period_len)
        self.intra_value = nn.Parameter(intra_value)

        if n_head == 1:
            self.linear_intra_query = nn.Linear(
                period_len, period_len, bias=False)
        else:
            self.linear_intra_query = []
            self.linear_intra_key = []
            self.linear_intra_value = []

            for i in range(n_head):
                self.linear_intra_query.append(nn.Linear(
                    period_len, period_len // n_head, bias=False))
                self.linear_intra_key.append(nn.Linear(
                    period_len, period_len // n_head, bias=False))
                self.linear_intra_value.append(nn.Linear(
                    period_len, period_len // n_head, bias=False))
                self.register_module(
                    f'linear_intra_query_{i}', self.linear_intra_query[i])
                self.register_module(
                    f'linear_intra_key_{i}', self.linear_intra_key[i])
                self.register_module(
                    f'linear_intra_value_{i}', self.linear_intra_value[i])

            self.linear_intra = nn.Linear(
                    (period_len // n_head) * n_head, period_len, bias=False)
        self.linear_inter = nn.Linear(
            n_seg_x, n_seg_y, bias=False)

        self.pred_len = pred_len
        self.seq_dim = seq_dim
        self.period_len = period_len
        self.n_seg_x = n_seg_x
        self.n_seg_y = n_seg_y
        self.n_head = n_head

    def forward(self, x):
        seq_len_norm = self.n_seg_x * self.period_len
        pred_len_norm = self.n_seg_y * self.period_len

        x = x[:, :, :seq_len_norm]
        x = x.reshape(
            -1, self.seq_dim, self.n_seg_x,
            self.period_len)

        if self.n_head == 1:
            query = self.linear_intra_query(x)
            key = self.intra_key
            value = self.intra_value

            key = key.permute(1, 0)
            attn = torch.matmul(query, key)
            attn = nn.ReLU()(attn)
            h = torch.matmul(attn, value)
        else:
            query = x
            key = self.intra_key
            value = self.intra_value

            h = []
            for i in range(self.n_head):
                query_i = self.linear_intra_query[i](query)
                key_i = self.linear_intra_key[i](key)
                value_i = self.linear_intra_value[i](value)

                key_i = key_i.permute(1, 0)
                attn_i = torch.matmul(query_i, key_i)
                attn_i = nn.ReLU()(attn_i)
                h.append(torch.matmul(attn_i, value_i))
            h = torch.concat(h, 3)
            h = self.linear_intra(h)

        x = x + h

        x = x.reshape(-1, self.n_seg_x,
                      self.period_len)
        x = x.permute(0, 2, 1)

        y = self.linear_inter(x)
        y = y.permute(0, 2, 1)
        y = y.reshape(-1, self.seq_dim,
                      pred_len_norm)
        y = y[:, :, :self.pred_len]
        return y


class Aggregation(nn.Module):
    def __init__(self, seq_len, seq_dim, period_len):
        super(Aggregation, self).__init__()

        padding = int(period_len // 2)
        kernel_size = int(1 + 2 * padding)
        self.conv1d = nn.Conv1d(
            in_channels=1, out_channels=1,
            kernel_size=kernel_size,
            stride=1, padding=padding,
            padding_mode="zeros", bias=False)

        self.seq_dim = seq_dim
        self.seq_len = seq_len

    def forward(self, x):
        h = x.reshape(-1, 1, self.seq_len)
        h = self.conv1d(h)
        h = h.reshape(-1, self.seq_dim, self.seq_len)
        return h + x


class UltraSTF(nn.Module):
    def __init__(self, seq_len, pred_len, seq_dim, period_len,
                 n_shape, is_normal, n_layer, n_head=1):
        super(UltraSTF, self).__init__()
        self.model_name = 'UltraSTF'

        self.aggregation = Aggregation(
            seq_len, seq_dim, period_len)

        layers = OrderedDict()
        for i in range(n_layer):
            if i == n_layer - 1:
                pred_len_ = pred_len
            else:
                pred_len_ = seq_len
            layers[f'block_{i}'] = Block(
                seq_len, pred_len_, seq_dim,
                period_len, n_shape, n_head)
        block = nn.Sequential(layers)
        self.add_module('block', block)
        self.block = block

        self.seq_len = seq_len
        self.is_normal = is_normal

    def forward(self, x):
        # x = [batch_size, seq_dim, seq_len, ]
        # y = [batch_size, seq_dim, pred_len, ]
        x = x[:, :, :self.seq_len]
        if self.is_normal:
            x_ = x.detach()
            x_mu = torch.mean(x_, 2, keepdim=True)
            x_sigma = torch.std(x_, 2, keepdim=True)
            x_sigma[x_sigma < 1e-6] = 1.0
            x = (x - x_mu) / x_sigma

        h = self.aggregation(x)
        y = self.block(h)

        if self.is_normal:
            y = (y * x_sigma) + x_mu
        return y

    def get_n_param(self):
        n_param = 0
        for param in self.parameters():
            if param.requires_grad:
                n_param += torch.numel(param)
        return n_param
