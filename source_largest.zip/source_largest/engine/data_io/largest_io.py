# -*- coding: utf-8 -*-
"""
@author:
"""


import numpy as np
from torch.utils.data import Dataset
from torch.utils.data import DataLoader


def _normalize(data):
    data_mu = np.mean(data)
    data_sigma = np.std(data)
    if data_sigma < 1e-06:
        data_sigma = 1
    data -= data_mu
    data /= data_sigma
    return data


def _convert_circular(data):
    data_0 = np.cos(data * 2 * np.pi)
    data_1 = np.sin(data * 2 * np.pi)
    return np.array([data_0, data_1, ])


class TimeSeries(Dataset):
    def __init__(self, data, tod, dow, lat, lng, direction,
                 seq_len, pred_len, partition,
                 frac_test=0.2, frac_valid=0.2, frac_train=0.6,
                 feature_variant=1, seed=666, is_pad=False,
                 pct_new=0.0, pct_missing=0.0):
        assert partition in ['train', 'valid', 'test', ]

        self.seq_len = seq_len
        self.pred_len = pred_len
        self.is_pad = is_pad

        seq_dim = data.shape[1]
        rng = np.random.default_rng(seed)
        random_vec = rng.permutation(seq_dim)

        mask_not_new = np.ones(seq_dim, dtype=bool)
        n_new = 0
        if pct_new > 0:
            n_new = np.ceil(seq_dim * pct_new)
            n_new = int(n_new)
            mask_not_new[random_vec[:n_new]] = False
        self.mask_not_new = mask_not_new

        mask_not_missing = np.ones(seq_dim, dtype=bool)
        n_missing = 0
        if pct_missing > 0:
            n_missing = np.ceil(seq_dim * pct_missing)
            n_missing = int(n_missing)
            mask_not_missing[random_vec[n_new:n_missing]] = False
        self.mask_not_missing = mask_not_missing

        n_data = data.shape[0]
        n_test = int(n_data * frac_test)
        n_valid = int(n_data * frac_valid)
        data_usage = frac_test + frac_valid + frac_train
        if np.isclose(data_usage, 1.0):
            n_train = n_data - n_test - n_valid
            n_nonuse = 0
        else:
            n_train = int(n_data * frac_train)
            n_nonuse = n_data - n_test - n_valid - n_train

        train_start = max(0, n_nonuse - seq_len)
        train_end = n_nonuse + n_train
        data_mu = np.mean(data[train_start:train_end, :],
                          axis=0, keepdims=True)
        data_sigma = np.std(data[train_start:train_end, :],
                            axis=0, keepdims=True)
        data_sigma[0, data_sigma[0, :] < 1e-6] = 1

        self.data_mu = np.expand_dims(data_mu.T, 0)
        self.data_sigma = np.expand_dims(data_sigma.T, 0)

        if partition == 'train':
            segment_start = max(0, n_nonuse - seq_len)
            segment_end = n_nonuse + n_train
        elif partition == 'valid':
            segment_start = n_nonuse + n_train - seq_len
            segment_end = n_nonuse + n_train + n_valid
        elif partition == 'test':
            segment_start = n_nonuse + n_train + n_valid - seq_len
            segment_end = n_data

        self.partition = partition
        self.feature_variant = feature_variant
        self.data = ((data[segment_start:segment_end, :] - data_mu) /
                     data_sigma)
        self.tod = tod[segment_start:segment_end]
        self.dow = dow[segment_start:segment_end]

        self.lat = np.expand_dims(_normalize(lat), 1)
        self.lng = np.expand_dims(_normalize(lng), 1)
        self.direction = np.zeros((direction.shape[0], 4))
        self.direction[direction == 0, 0] = 1
        self.direction[direction == 1, 1] = 1
        self.direction[direction == 2, 2] = 1
        self.direction[direction == 3, 3] = 1
        self.direction[:, 0] = _normalize(self.direction[:, 0])
        self.direction[:, 1] = _normalize(self.direction[:, 1])
        self.direction[:, 2] = _normalize(self.direction[:, 2])
        self.direction[:, 3] = _normalize(self.direction[:, 3])
        self.n_data = self.data.shape[0] - seq_len - pred_len + 1

    def __len__(self):
        return self.n_data

    def __getitem__(self, index):
        partition = self.partition
        feature_variant = self.feature_variant

        seq_len = self.seq_len
        pred_len = self.pred_len
        is_pad = self.is_pad

        x_start = index
        x_end = x_start + seq_len

        y_start = x_end
        y_end = y_start + pred_len

        data_x = self.data[x_start:x_end, :].T
        data_y = self.data[y_start:y_end, :].T

        if feature_variant == 0:
            pass  # no feature is used
        if feature_variant == 1:
            n_dim = data_x.shape[0]
            feat_x = np.concatenate(
                (self.tod[x_start:x_end], self.dow[x_start:x_end], ),
                axis=0)
            feat_x = np.tile(feat_x, (n_dim, 1))
            data_x = np.concatenate((data_x, feat_x, ), axis=1)
        elif feature_variant == 2:
            n_dim = data_x.shape[0]
            tod_feat = _convert_circular(self.tod[x_end])
            dow_feat = _convert_circular(self.dow[x_end])

            time_feat = np.concatenate(
                (tod_feat, dow_feat, ), axis=0)
            time_feat = np.tile(time_feat, (n_dim, 1))
            data_x = np.concatenate(
                (data_x, time_feat, self.lat, self.lng,
                 self.direction, ), axis=1)
            # seq_len + 4 + 1 + 1 + 4

        if is_pad:
            if partition == 'train':
                data_x[np.logical_not(self.mask_not_new), :] = 0
                data_y[np.logical_not(self.mask_not_new), :] = 0
            elif partition == 'valid' or partition == 'test':
                data_x[np.logical_not(self.mask_not_missing), :] = 0
                data_y[np.logical_not(self.mask_not_missing), :] = 0
        else:
            if partition == 'train':
                data_x = data_x[self.mask_not_new, :]
                data_y = data_y[self.mask_not_new, :]
            elif partition == 'valid' or partition == 'test':
                data_x = data_x[self.mask_not_missing, :]
                data_y = data_y[self.mask_not_missing, :]
        return data_x, data_y

    def inverse_transform(self, data):
        partition = self.partition
        is_pad = self.is_pad
        if is_pad:
            if partition == 'train':
                data[:, self.mask_not_new, :] = (
                    (data[:, self.mask_not_new, :] *
                     self.data_sigma[:, self.mask_not_new, :]) +
                    self.data_mu[:, self.mask_not_new, :])
            elif partition == 'valid' or partition == 'test':
                data[:, self.mask_not_missing, :] = (
                    (data[:, self.mask_not_missing, :] *
                     self.data_sigma[:, self.mask_not_missing, :]) +
                    self.data_mu[:, self.mask_not_missing, :])
        else:
            if partition == 'train':
                data = ((data * self.data_sigma[:, self.mask_not_new, :]) +
                        self.data_mu[:, self.mask_not_new, :])
            elif partition == 'valid' or partition == 'test':
                data = ((data * self.data_sigma[:, self.mask_not_missing, :]) +
                        self.data_mu[:, self.mask_not_missing, :])
        return data

    def get_mask(self):
        partition = self.partition
        if partition == 'train':
            return self.mask_not_new
        elif partition == 'valid' or partition == 'test':
            return self.mask_not_missing


def get_time_series_loader(partition, config, n_worker, is_pad=False):
    data_path = config['data']['data_path']

    seq_len = int(config['data']['seq_len'])
    pred_len = int(config['data']['pred_len'])
    frac_test = float(config['data']['frac_test'])
    frac_valid = float(config['data']['frac_valid'])
    frac_train = float(config['data']['frac_train'])
    feature_variant = int(config['data']['feature_variant'])

    seed = int(config['data']['seed'])
    pct_new = float(config['data']['pct_new'])
    pct_missing = float(config['data']['pct_missing'])

    batch_size = int(config['model']['batch_size'])

    shuffle_flag = False
    drop_last_flag = False
    if partition == 'train':
        shuffle_flag = True
        drop_last_flag = True

    data = np.load(data_path)['data']
    tod = np.load(data_path)['tod']
    dow = np.load(data_path)['dow']
    lat = np.load(data_path)['lat']
    lng = np.load(data_path)['lng']
    direction = np.load(data_path)['direction']

    dataset = TimeSeries(
        data, tod, dow, lat, lng, direction, seq_len, pred_len, partition,
        frac_test=frac_test, frac_valid=frac_valid, frac_train=frac_train,
        feature_variant=feature_variant, seed=seed, is_pad=is_pad,
        pct_new=pct_new, pct_missing=pct_missing)
    data_loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle_flag,
        num_workers=n_worker,
        drop_last=drop_last_flag)
    return data_loader, dataset

