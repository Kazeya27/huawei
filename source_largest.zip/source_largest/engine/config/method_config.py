# -*- coding: utf-8 -*-
"""
@author:
"""


import os
from .util import write_config


def get_methods(config_dir):
    prefix = 'lin'
    config_id = 0
    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_linear()
    write_config(config_dict, config_path)

    prefix = 'tsm'
    config_id = 0
    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_tsmixer()
    write_config(config_dict, config_path)

    prefix = 'rpm'
    config_id = 0
    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_rpmixer()
    write_config(config_dict, config_path)

    prefix = 'itx'
    config_id = 0
    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_itrain()
    write_config(config_dict, config_path)

    prefix = 'spa'
    config_id = 0
    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_sparse()
    config_dict['model']['n_hidden'] = 0
    config_dict['model']['is_shape'] = 0
    config_dict['model']['n_layer'] = 1
    config_dict['model']['lr'] = 0.025
    write_config(config_dict, config_path)
    config_id += 1

    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_sparse()
    config_dict['model']['n_hidden'] = 32
    config_dict['model']['is_shape'] = 0
    config_dict['model']['n_layer'] = 1
    config_dict['model']['lr'] = 0.025
    write_config(config_dict, config_path)
    config_id += 1

    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_sparse()
    config_dict['model']['n_hidden'] = 32
    config_dict['model']['is_shape'] = 0
    config_dict['model']['n_layer'] = 4
    config_dict['model']['lr'] = 0.0025
    write_config(config_dict, config_path)
    config_id += 1

    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_sparse()
    config_dict['model']['n_hidden'] = 0
    config_dict['model']['is_shape'] = 2
    config_dict['model']['n_layer'] = 4
    config_dict['model']['lr'] = 0.0025
    write_config(config_dict, config_path)

    prefix = 'ult'
    config_id = 0
    config_path = os.path.join(
        config_dir, f'{prefix}_{config_id:04d}.config')
    config_dict = _get_ultra()
    write_config(config_dict, config_path)


def _get_linear():
    seq_len = 720
    n_layer = 1
    is_normal = 'True'

    lr = 0.025
    n_epoch = 100
    batch_size = 32

    config = {}
    config['model'] = {}
    config['model']['model_name'] = 'Linear'
    config['model']['seq_len'] = seq_len
    config['model']['n_layer'] = n_layer
    config['model']['is_normal'] = is_normal

    config['model']['lr'] = lr
    config['model']['n_epoch'] = n_epoch
    config['model']['batch_size'] = batch_size
    return config


def _get_tsmixer():
    seq_len = 96
    hidden_dim = 64
    n_block = 8
    activation = 'gelu'
    dropout = 0.0
    is_normal = 'True'

    lr = 0.025
    n_epoch = 100
    batch_size = 32

    config = {}
    config['model'] = {}
    config['model']['model_name'] = 'TSMixer'
    config['model']['seq_len'] = seq_len
    config['model']['hidden_dim'] = hidden_dim
    config['model']['n_block'] = n_block
    config['model']['activation'] = activation
    config['model']['dropout'] = dropout
    config['model']['is_normal'] = is_normal

    config['model']['lr'] = lr
    config['model']['n_epoch'] = n_epoch
    config['model']['batch_size'] = batch_size
    return config


def _get_itrain():
    seq_len = 96
    d_model = 512
    n_heads = 8
    d_ff = 512
    n_layer = 4
    dropout = 0.1
    is_normal = 'True'

    lr = 0.0025
    n_epoch = 100
    batch_size = 16

    config = {}
    config['model'] = {}
    config['model']['model_name'] = 'iTransformer'
    config['model']['seq_len'] = seq_len
    config['model']['d_model'] = d_model
    config['model']['n_heads'] = n_heads
    config['model']['d_ff'] = d_ff
    config['model']['n_layer'] = n_layer
    config['model']['dropout'] = dropout
    config['model']['is_normal'] = is_normal

    config['model']['lr'] = lr
    config['model']['n_epoch'] = n_epoch
    config['model']['batch_size'] = batch_size
    return config


def _get_sparse():
    seq_len = 720
    period_len = 12
    n_hidden = 0
    is_shape = 1
    n_shape = 16
    n_layer = 4
    is_normal = 'True'

    lr = 0.0025
    n_epoch = 100
    batch_size = 32

    config = {}
    config['model'] = {}
    config['model']['model_name'] = 'SparseTSF'
    config['model']['seq_len'] = seq_len
    config['model']['period_len'] = period_len
    config['model']['n_hidden'] = n_hidden
    config['model']['is_shape'] = is_shape
    config['model']['n_shape'] = n_shape
    config['model']['n_layer'] = n_layer
    config['model']['is_normal'] = is_normal

    config['model']['lr'] = lr
    config['model']['n_epoch'] = n_epoch
    config['model']['batch_size'] = batch_size
    return config


def _get_ultra():
    seq_len = 720
    period_len = 12
    n_shape = 16
    n_layer = 4
    is_normal = 'True'

    lr = 0.0025
    n_epoch = 100
    batch_size = 32

    config = {}
    config['model'] = {}
    config['model']['model_name'] = 'UltraSTF'
    config['model']['seq_len'] = seq_len
    config['model']['period_len'] = period_len
    config['model']['n_shape'] = n_shape
    config['model']['n_layer'] = n_layer
    config['model']['is_normal'] = is_normal

    config['model']['lr'] = lr
    config['model']['n_epoch'] = n_epoch
    config['model']['batch_size'] = batch_size
    return config


def _get_rpmixer():
    seq_len = 96
    proj_dim = -1
    dim_factor = 1.0
    n_layer = 8
    norm_layer = 'BN'
    activation = 'gelu'
    is_preact = 'True'
    is_random = 'True'
    is_normal = 'True'
    is_freq = 'False'

    lr = 0.025
    n_epoch = 100
    batch_size = 32

    config = {}
    config['model'] = {}
    config['model']['model_name'] = 'RPMixer'
    config['model']['seq_len'] = seq_len
    config['model']['proj_dim'] = proj_dim
    config['model']['dim_factor'] = dim_factor
    config['model']['n_layer'] = n_layer
    config['model']['norm_layer'] = norm_layer
    config['model']['activation'] = activation
    config['model']['is_preact'] = is_preact
    config['model']['is_random'] = is_random
    config['model']['is_normal'] = is_normal
    config['model']['is_freq'] = is_freq

    config['model']['lr'] = lr
    config['model']['n_epoch'] = n_epoch
    config['model']['batch_size'] = batch_size
    return config

