# -*- coding: utf-8 -*-
"""
@author:
"""

import os
import joblib
import numpy as np


def print_result(data_config, method, method_name):
    result_dir = os.path.join(
        '.', 'result', data_config)

    result_path = os.path.join(
        result_dir, f'{method}_9999.joblib')
    if not os.path.exists(result_path):
        return

    result_pkl = joblib.load(result_path)
    metric_test = result_pkl['metric_test']

    output_str = f'{method_name},{result_pkl["n_param"]},'
    output_str += (f"{metric_test['mae'][2]:.2f},"
                   f"{metric_test['rmse'][2]:.2f},"
                   f"{metric_test['mape'][2]:.2f},"
                   f"{metric_test['mae'][5]:.2f},"
                   f"{metric_test['rmse'][5]:.2f},"
                   f"{metric_test['mape'][5]:.2f},"
                   f"{metric_test['mae'][11]:.2f},"
                   f"{metric_test['rmse'][11]:.2f},"
                   f"{metric_test['mape'][11]:.2f},"
                   f"{np.mean(metric_test['mae']):.2f},"
                   f"{np.mean(metric_test['rmse']):.2f},"
                   f"{np.mean(metric_test['mape']):.2f},")

    print(output_str)


def main():
    data_names = [
        'sd_his_2019_agg',
        'gba_his_2019_agg',
        'gla_his_2019_agg',
        'ca_his_2019_agg',
    ]

    methods = [
        'lin_0000',
        'tsm_0000',
        'rpm_0000',
        'itx_0000',
        'spa_0000',
        'spa_0001',
        'spa_0002',
        'spa_0003',
        'ult_0000',
    ]

    method_names = [
        'Linear',
        'TSMixer',
        'RPMixer',
        'iXFMR',
        'SparseTSF',
        'SparseTSF+MLP',
        'SparseTSF+MLPx4',
        'SparseTSF+SA',
        'UltraSTF',
    ]

    for data_name in data_names:
        print(data_name)
        print(('method,n_param,'
               'MAE@3,RMSE@3,MAPE@3,'
               'MAE@6,RMSE@6,MAPE@6,'
               'MAE@12,RMSE@12,MAPE@12,'
               'MAE(avg),RMSE(avg),MAPE(avg),'))
        data_config = f'{data_name}_0000'
        for method, method_name in zip(methods, method_names):
            print_result(data_config, method, method_name)
        print()


if __name__ == '__main__':
    main()

